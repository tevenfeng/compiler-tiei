
public class EmptySymTableException extends RuntimeException {
    public EmptySymTableException(){
        
    }
}
