
public class DuplicateSymException extends RuntimeException {
    public DuplicateSymException(){
        
    }
}
